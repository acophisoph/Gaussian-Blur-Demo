import random
import numpy as np
import scipy
from scipy.stats import multivariate_normal
from tkinter import *



#Initial Values

#matrix size (doesnt do anything yet)
n = 5
#the radius of the blur
r = 1
#values for the matrix
m = np.array(
  [ [0,0,0,0,0],
    [0,1,1,1,0],
    [0,1,1,1,0],
    [0,1,1,1,0],
    [0,0,0,0,0] ], dtype = int)
print("Array matrix is:\n",m)
#type of array



#Calculate Gaussian Blur

#location matrix
locm = np.array(
  [ [(-2,-2),(-1,-2),(0,-2),(1,-2),(2,-2)],
    [(-2,-1),(-1,-1),(0,-1),(1,-1),(2,-1)],
    [(-2,0) ,(-1,0) ,(0,0) ,(1,0) ,(2,0) ],
    [(-2,1) ,(-1,1) ,(0,1) ,(1,1) ,(2,1) ],
    [(-2,2) ,(-1,2) ,(0,2) ,(1,2) ,(2,2) ], ], dtype = int)
#values for gaussian function
mu = 0
sigma = r+0.5
#create a multivariate Gaussian object with specified mean and covariance matrix
mvn = multivariate_normal([mu, mu],[sigma, sigma]) 
#Find weights for each cell
sumweights = 0
for i in range(-r,r+1):
  for j in range(-r,r+1):
    #evaluate the probability density at x
    p = mvn.pdf([j,i])
    sumweights = sumweights + p
#Calculate Gaussian for each nearby point
total = 0
for i in range(int((n-1)/2)-r,int((n-1)/2)+r+1):
  for j in range(int((n-1)/2)-r,int((n-1)/2)+r+1):
    #Find weights of each pixel again
    loc = locm[j,i]
    #evaluate the probability density at x
    p = mvn.pdf(loc)
    #normalize sum total of weights to add to 1
    weightnormed = p/sumweights
    #Get actual matrix data
    mat = m[j,i]
    #multiply matrix data by weights
    total = total + mat*weightnormed
print("The value for the cell in the center is")
print(total)


'''
https://www.pixelstech.net/article/1353768112-Gaussian-Blur-Algorithm
'''



'''
#all intial variable needed
radius = 1

def matrices():
  print(matrix)

def ini():
    a=int(ent1.get())
    matrix = np.zeros(shape=(a,a), dtype=int)
    print(matrix)
    ###output.insert(1.0,matrix)
    win=Tk() #creating the main window and storing the window object in 'win'
    win.title('Matrix')
    win.geometry('300x300') #setting the size of the window
    text=Label(win, text='Enter what size matrix you want in the below fields and click Next')
    for i in matrix:
      for j in i:
        j = Entry(win) 
    btn=Button(text='Enter',command=matrices)
    text.pack()
    ent1.pack()
    btn.pack()
    win.mainloop()

    
win=Tk() #creating the main window and storing the window object in 'win'
win.title('Matrix')
win.geometry('300x300') #setting the size of the window
text=Label(win, text='Enter what size matrix you want in the below fields and click Next')
ent1 = Entry(win) 
btn=Button(text='Next',command=ini)
###output=Text(win,height=1,width=6)
text.pack()
ent1.pack()
###output.pack()
btn.pack()
win.mainloop()



#values for gaussian function
mu = 0
sigma = radius+0.5
matrix = ([[11, 0, 9], [3, 4, 1], [2, 0, 3]])



x = 0
mvn = multivariate_normal(mu,sigma) #create a multivariate Gaussian object with specified mean and covariance matrix
p = mvn.pdf(x) #evaluate the probability density at x
'''


'''
https://kharisecario.wordpress.com/2017/03/25/create-nxn-matrix-in-pythonnumpy/
https://pythongeeks.org/gui-programming-in-python/
'''